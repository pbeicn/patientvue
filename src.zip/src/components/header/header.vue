<template>
    <a-row type="flex" justify="space-around" class="reg_h1" align="middle">
      <a-col :span="6">
        <a-row type="flex" justify="space-around" align="middle">
          <a-col :span="2"></a-col>
          <a-col :span="2">
            <router-link to="/">
              <font-awesome-icon icon="angle-left" class="reg_h2" />
            </router-link>
          </a-col>
          <a-col :span="20" class="reg_head">
            <router-link to="/main">
              <span class="reg_h2">返回</span>
            </router-link>
          </a-col>
        </a-row>
      </a-col>
      <a-col :span="13">
        <span class="reg_h3">扫码登录</span>
      </a-col>
      <a-col :span="5"></a-col>
    </a-row>
</template>
<script>
export default {
    
}
</script>